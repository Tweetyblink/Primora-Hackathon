
  # NGO Design Program Website

  This is a code bundle for NGO Design Program Website. The original project is available at https://www.figma.com/design/owUJQ7qLS8t6YbOrxq8RPy/NGO-Design-Program-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  