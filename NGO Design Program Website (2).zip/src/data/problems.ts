export interface Problem {
  id: string;
  title: string;
  category: 'literacy' | 'career';
  icon: string;
  description: string;
}

export const literacyProblems: Problem[] = [
  {
    id: 'phonological-awareness',
    title: 'Phonological Awareness',
    category: 'literacy',
    icon: 'Volume2',
    description: 'Students develop phonological awareness necessary for early reading'
  },
  {
    id: 'decode-reading',
    title: 'Decode and Read Fluently',
    category: 'literacy',
    icon: 'Book',
    description: 'Students are able to decode and read grade-appropriate texts fluently'
  },
  {
    id: 'comprehend-written',
    title: 'Comprehend Written Text',
    category: 'literacy',
    icon: 'FileText',
    description: 'Students are able to comprehend grade-appropriate written text'
  },
  {
    id: 'understand-spoken',
    title: 'Understand Spoken Language',
    category: 'literacy',
    icon: 'Ear',
    description: 'Students are able to understand spoken explanations and meaning'
  },
  {
    id: 'express-spoken',
    title: 'Express Ideas Orally',
    category: 'literacy',
    icon: 'MessageCircle',
    description: 'Students are able to express ideas clearly through spoken language'
  },
  {
    id: 'express-writing',
    title: 'Express Ideas in Writing',
    category: 'literacy',
    icon: 'PenTool',
    description: 'Students are able to express ideas clearly through basic writing'
  },
  {
    id: 'number-sense',
    title: 'Number Sense',
    category: 'literacy',
    icon: 'Hash',
    description: 'Students develop strong number sense appropriate to their grade'
  },
  {
    id: 'arithmetic-operations',
    title: 'Arithmetic Operations',
    category: 'literacy',
    icon: 'Calculator',
    description: 'Students are able to perform grade-appropriate arithmetic operations'
  },
  {
    id: 'word-problems',
    title: 'Apply Numeracy to Problems',
    category: 'literacy',
    icon: 'Target',
    description: 'Students are able to apply numeracy to word problems'
  },
  {
    id: 'measurement',
    title: 'Basic Measurement',
    category: 'literacy',
    icon: 'Ruler',
    description: 'Students understand basic measurement concepts'
  },
  {
    id: 'math-reasoning',
    title: 'Mathematical Reasoning',
    category: 'literacy',
    icon: 'Brain',
    description: 'Students demonstrate grade-appropriate mathematical reasoning'
  }
];

export const careerProblems: Problem[] = [
  {
    id: 'career-awareness',
    title: 'Career Pathway Awareness',
    category: 'career',
    icon: 'Compass',
    description: 'Students demonstrate awareness of diverse education and career pathways'
  },
  {
    id: 'education-career-link',
    title: 'Education-Skills-Career Link',
    category: 'career',
    icon: 'Link',
    description: 'Students understand the link between education, skills, and career options'
  },
  {
    id: 'decision-making',
    title: 'Decision Making & Goal Setting',
    category: 'career',
    icon: 'Target',
    description: 'Students demonstrate decision-making and goal-setting related to their future'
  },
  {
    id: 'plan-pathways',
    title: 'Plan Future Pathways',
    category: 'career',
    icon: 'Map',
    description: 'Students are able to plan pathways beyond school'
  },
  {
    id: 'life-skills',
    title: 'Essential Life & Workplace Skills',
    category: 'career',
    icon: 'Briefcase',
    description: 'Students demonstrate essential life and workplace skills'
  },
  {
    id: 'confidence-agency',
    title: 'Confidence & Agency',
    category: 'career',
    icon: 'Award',
    description: 'Students show confidence and agency in making education and career choices'
  }
];
