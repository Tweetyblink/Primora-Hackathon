export interface ProblemCause {
  student: string;
  teacher: string;
  system: string;
}

export const problemCauses: Record<string, ProblemCause> = {
  // Basic Measurement
  'measurement': {
    student: 'Limited real-life exposure to measurement and weak foundational numeracy skills.',
    teacher: 'Measurement taught procedurally with little hands-on or conceptual practice.',
    system: 'Lack of tools, time, or classroom conditions for activity-based learning.',
  },
  
  // Mathematical Reasoning
  'math-reasoning': {
    student: 'Gaps in foundational skills and low confidence in explaining reasoning.',
    teacher: 'Emphasis on correct answers over reasoning and discussion.',
    system: 'Assessments and curriculum pressures limit reasoning-focused instruction.',
  },
  
  // Career Pathway Awareness
  'career-awareness': {
    student: 'Limited exposure to career options beyond immediate surroundings.',
    teacher: 'Career guidance not integrated into regular teaching practices.',
    system: 'Few structured career guidance programs or external partnerships.',
  },
  
  // Education-Skills-Career Link
  'education-career-link': {
    student: 'Difficulty connecting school learning to real-world skills and careers.',
    teacher: 'Limited use of examples linking subjects to skills and career paths.',
    system: 'Career readiness not embedded in curriculum or school structures.',
  },
  
  // Phonological Awareness
  'phonological-awareness': {
    student: 'Students struggle to hear and manipulate sounds needed for early reading.',
    teacher: 'Teachers lack structured strategies to explicitly teach phonemic skills.',
    system: 'Early-grade curriculum and assessments underemphasize phonological foundations.',
  },
  
  // Decode and Read Fluently
  'decode-reading': {
    student: 'Students cannot fluently decode grade-level text due to weak foundational reading skills.',
    teacher: 'Teachers lack structured methods to build decoding and reading fluency.',
    system: 'Early literacy programs do not ensure systematic phonics and fluency practice.',
  },
  
  // Comprehend Written Text
  'comprehend-written': {
    student: 'Students struggle to understand and respond to grade-level written text.',
    teacher: 'Teachers lack strategies to build reading comprehension skills systematically.',
    system: 'Curriculum and assessments focus on decoding more than comprehension.',
  },
  
  // Understand Spoken Language
  'understand-spoken': {
    student: 'Students struggle to follow and interpret spoken instructions and explanations.',
    teacher: 'Teachers lack techniques to build listening comprehension and oral understanding.',
    system: 'Classroom practices and assessments rarely focus on structured listening skills.',
  },
  
  // Express Ideas Orally
  'express-spoken': {
    student: 'Limited practice opportunities lead to low confidence in verbal expression.',
    teacher: 'Lack time/training to facilitate and assess oral communication effectively.',
    system: 'Curriculum overemphasizes written work, neglecting oral skills development.',
  },
  
  // Express Ideas in Writing
  'express-writing': {
    student: 'Struggle with organizing thoughts coherently and translating ideas into written form.',
    teacher: 'Limited time for individualized writing instruction and personalized feedback.',
    system: 'Standardized curricula focus on rote mechanics over meaningful expression and creativity.',
  },
  
  // Number Sense
  'number-sense': {
    student: 'Weak foundational understanding of numerical relationships and mental math strategies.',
    teacher: 'Insufficient resources and training for hands-on, conceptual number sense instruction.',
    system: 'Overemphasis on procedural computation rather than deep conceptual understanding of numbers.',
  },
  
  // Arithmetic Operations
  'arithmetic-operations': {
    student: 'Memorize procedures without understanding underlying mathematical concepts and relationships.',
    teacher: 'Rely on rote drills instead of concrete, visual, and conceptual teaching methods.',
    system: 'Timed assessments prioritize speed over accuracy and conceptual mastery.',
  },
  
  // Apply Numeracy to Problems
  'word-problems': {
    student: 'Struggle to decode word problems and connect mathematical operations to real-world contexts.',
    teacher: 'Lack strategies to teach problem-solving skills beyond keyword identification methods.',
    system: 'Assessments use complex language that obscures mathematical thinking, disadvantaging diverse learners.',
  },
  
  // Decision Making & Goal Setting
  'decision-making': {
    student: 'Students lack basic reading and number skills due to weak practice and low support.',
    teacher: 'Teachers cannot teach at students\' levels due to overload and limited FLN training.',
    system: 'The system fails to assess early and provide structured remediation.',
  },
  
  // Plan Future Pathways
  'plan-pathways': {
    student: 'Students lack exposure and guidance to identify interests and future academic paths.',
    teacher: 'Teachers have limited time and tools to provide structured career/academic guidance.',
    system: 'Schools lack an integrated framework to embed early career awareness and planning.',
  },
  
  // Essential Life & Workplace Skills
  'life-skills': {
    student: 'Students lack practical exposure to real-life problem solving and workplace behaviours.',
    teacher: 'Teachers are not equipped or trained to integrate life and employability skills into daily teaching.',
    system: 'The curriculum and assessment system do not prioritize structured life-skill development.',
  },
  
  // Confidence & Agency
  'confidence-agency': {
    student: 'Students hesitate to express choices and take initiative due to low self-belief.',
    teacher: 'Teachers rarely create safe spaces that encourage student voice and decision-making.',
    system: 'Schools lack structured opportunities that build leadership and student ownership.',
  },
};