import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { literacyProblems, careerProblems } from '@/data/problems';
import { problemCauses } from '@/data/problemCauses';
import { Button } from '@/app/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Textarea } from '@/app/components/ui/textarea';
import { Progress } from '@/app/components/ui/progress';
import { StatusButton, TaskStatus } from '@/app/components/StatusButton';
import { ArrowLeft, Users, GraduationCap, Home, Star, AlertCircle, Building2 } from 'lucide-react';
import nightSkyBg from 'figma:asset/1fed1153c2875de5502e9ab7a4d6b263492f0d7b.png';

export function WorkflowPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const allProblems = [...literacyProblems, ...careerProblems];
  const problem = allProblems.find((p) => p.id === id);

  const [surveyStatus, setSurveyStatus] = useState<TaskStatus>('not-started');
  const [workshopStatus, setWorkshopStatus] = useState<TaskStatus>('not-started');
  const [finalSurveyStatus, setFinalSurveyStatus] = useState<TaskStatus>('not-started');
  const [notes, setNotes] = useState('');
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedback, setFeedback] = useState('');

  if (!problem) {
    return <div>Problem not found</div>;
  }

  // Get problem causes for this specific problem
  const causes = id && problemCauses[id] ? problemCauses[id] : {
    student: 'Student-related factors contributing to this problem.',
    teacher: 'Teacher-related factors contributing to this problem.',
    system: 'System-related factors contributing to this problem.',
  };

  // Calculate progress based on completed tasks
  const calculateProgress = () => {
    let completed = 0;
    const total = 3;
    
    if (surveyStatus === 'done') completed++;
    if (workshopStatus === 'done') completed++;
    if (finalSurveyStatus === 'done') completed++;
    
    return (completed / total) * 100;
  };

  const progress = calculateProgress();

  // Calculate points for gamification
  const calculatePoints = () => {
    let points = 0;
    if (surveyStatus === 'done') points += 100;
    if (workshopStatus === 'done') points += 100;
    if (finalSurveyStatus === 'done') points += 100;
    return points;
  };

  const points = calculatePoints();

  const handleNotWorked = () => {
    setShowFeedback(true);
  };

  const handleSubmitFeedback = () => {
    // Handle feedback submission
    alert('Feedback submitted! Thank you for your input.');
    setFeedback('');
    setShowFeedback(false);
  };

  return (
    <div 
      className="min-h-screen bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: `url(${nightSkyBg})` }}
    >
      {/* Overlay */}
      <div className="min-h-screen bg-gradient-to-b from-indigo-950/90 via-purple-900/80 to-indigo-950/90">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="flex items-center gap-4 mb-8">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(`/problem/${id}`)}
              className="text-white hover:bg-white/10"
            >
              <ArrowLeft className="h-6 w-6" />
            </Button>
            <h1 className="text-3xl font-bold text-white">Design Workflow</h1>
          </div>

          {/* Gamified Progress Bar */}
          <Card className="mb-8 bg-white/95 backdrop-blur-sm">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Star className="h-6 w-6 text-yellow-500" />
                  Progress Tracker
                </CardTitle>
                <div className="text-2xl font-bold text-purple-600">
                  {points} / 300 Points
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between text-sm text-gray-600">
                  <span>Completion</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} className="h-3" />
                <div className="flex gap-4 mt-4">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    <span className="text-sm text-gray-600">Completed</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                    <span className="text-sm text-gray-600">In Progress</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-gray-300"></div>
                    <span className="text-sm text-gray-600">Not Started</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Problem Heading */}
          <Card className="mb-6 bg-white/95 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-2xl">{problem.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">{problem.description}</p>
              
              {/* Possible Problem Statements */}
              <div className="space-y-3">
                <h3 className="font-semibold text-lg">Possible Problem Causes:</h3>
                <div className="space-y-2">
                  <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                    <Users className="h-5 w-5 text-blue-600 mt-0.5 shrink-0" />
                    <div>
                      <span className="font-semibold text-gray-800">Student: </span>
                      <span className="text-gray-700">{causes.student}</span>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                    <GraduationCap className="h-5 w-5 text-green-600 mt-0.5 shrink-0" />
                    <div>
                      <span className="font-semibold text-gray-800">Teacher: </span>
                      <span className="text-gray-700">{causes.teacher}</span>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 bg-amber-50 rounded-lg">
                    <Building2 className="h-5 w-5 text-amber-600 mt-0.5 shrink-0" />
                    <div>
                      <span className="font-semibold text-gray-800">System: </span>
                      <span className="text-gray-700">{causes.system}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Survey from School */}
          <Card className="mb-6 bg-white/95 backdrop-blur-sm">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Conduct Survey from School</CardTitle>
                <StatusButton
                  status={surveyStatus}
                  onStatusChange={setSurveyStatus}
                />
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Survey students, teachers, and staff to understand the root causes of the problem.
                Gather quantitative and qualitative data.
              </p>
            </CardContent>
          </Card>

          {/* Workshop */}
          <Card className="mb-6 bg-white/95 backdrop-blur-sm">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Workshop</CardTitle>
                <StatusButton
                  status={workshopStatus}
                  onStatusChange={setWorkshopStatus}
                />
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-600">
                Conduct workshops with teachers and students to address the identified issues.
              </p>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Workshop Notes
                </label>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Take notes during the workshop. Include key insights, participant feedback, and observations..."
                  className="min-h-[120px]"
                />
              </div>

              <div className="p-4 bg-indigo-50 rounded-lg">
                <p className="text-sm text-indigo-900">
                  <strong>Next Step:</strong> Ask the teachers to conduct a test based on the workshop teachings
                  to measure effectiveness and understanding.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Final Survey */}
          <Card className="mb-6 bg-white/95 backdrop-blur-sm">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Final Survey</CardTitle>
                <StatusButton
                  status={finalSurveyStatus}
                  onStatusChange={setFinalSurveyStatus}
                />
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Conduct a final survey to evaluate the impact of the intervention and measure
                improvements in the identified problem area.
              </p>
            </CardContent>
          </Card>

          {/* Not Worked / Feedback Section */}
          <Card className="mb-6 bg-white/95 backdrop-blur-sm">
            <CardContent className="pt-6">
              {!showFeedback ? (
                <Button
                  onClick={handleNotWorked}
                  variant="outline"
                  className="w-full border-red-300 text-red-700 hover:bg-red-50"
                >
                  <AlertCircle className="h-4 w-4 mr-2" />
                  Not Worked - Provide Feedback
                </Button>
              ) : (
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg">Provide Feedback</h3>
                  <p className="text-sm text-gray-600">
                    Please share what didn't work and any suggestions for improvement.
                  </p>
                  <Textarea
                    value={feedback}
                    onChange={(e) => setFeedback(e.target.value)}
                    placeholder="Describe what challenges you faced, what didn't work as expected, and your suggestions..."
                    className="min-h-[120px]"
                  />
                  <div className="flex gap-3">
                    <Button
                      onClick={handleSubmitFeedback}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      Submit Feedback
                    </Button>
                    <Button
                      onClick={() => setShowFeedback(false)}
                      variant="outline"
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}