import { useState } from 'react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/app/components/ui/dropdown-menu';
import { Button } from '@/app/components/ui/button';
import { ChevronDown, Circle, Clock, CheckCircle2 } from 'lucide-react';

export type TaskStatus = 'not-started' | 'processing' | 'done';

interface StatusButtonProps {
  status: TaskStatus;
  onStatusChange: (status: TaskStatus) => void;
}

export function StatusButton({ status, onStatusChange }: StatusButtonProps) {
  const statusConfig = {
    'not-started': {
      label: 'Not Yet Started',
      icon: Circle,
      color: 'text-gray-400',
      bgColor: 'bg-gray-100 hover:bg-gray-200',
    },
    processing: {
      label: 'Processing',
      icon: Clock,
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-100 hover:bg-yellow-200',
    },
    done: {
      label: 'Done',
      icon: CheckCircle2,
      color: 'text-green-600',
      bgColor: 'bg-green-100 hover:bg-green-200',
    },
  };

  const currentStatus = statusConfig[status];
  const Icon = currentStatus.icon;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          className={`${currentStatus.bgColor} ${currentStatus.color} border-none gap-2`}
        >
          <Icon className="h-4 w-4" />
          {currentStatus.label}
          <ChevronDown className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuItem
          onClick={() => onStatusChange('not-started')}
          className="gap-2"
        >
          <Circle className="h-4 w-4 text-gray-400" />
          Not Yet Started
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={() => onStatusChange('processing')}
          className="gap-2"
        >
          <Clock className="h-4 w-4 text-yellow-600" />
          Processing
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={() => onStatusChange('done')}
          className="gap-2"
        >
          <CheckCircle2 className="h-4 w-4 text-green-600" />
          Done
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
