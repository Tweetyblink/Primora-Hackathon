import { useParams, useNavigate } from 'react-router-dom';
import { literacyProblems, careerProblems } from '@/data/problems';
import { Button } from '@/app/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import * as LucideIcons from 'lucide-react';
import { ArrowLeft, Lightbulb, Target, Users } from 'lucide-react';
import nightSkyBg from 'figma:asset/1fed1153c2875de5502e9ab7a4d6b263492f0d7b.png';

export function ProblemDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const allProblems = [...literacyProblems, ...careerProblems];
  const problem = allProblems.find(p => p.id === id);

  if (!problem) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900">
        <div className="text-center">
          <h1 className="text-2xl text-white mb-4">Problem not found</h1>
          <Button onClick={() => navigate('/')}>Go Home</Button>
        </div>
      </div>
    );
  }

  const getIcon = (iconName: string) => {
    const Icon = (LucideIcons as any)[iconName];
    return Icon ? <Icon className="h-12 w-12" /> : null;
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${nightSkyBg})` }}
      />
      
      {/* Dark overlay for better text readability */}
      <div className="absolute inset-0 bg-black/20" />

      {/* Content */}
      <div className="relative z-10">
        {/* Header */}
        <header className="pt-8 px-8">
          <div className="max-w-5xl mx-auto">
            <Button
              variant="ghost"
              onClick={() => navigate(`/problems/${problem.category}`)}
              className="text-white hover:bg-white/10 mb-4"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Problems
            </Button>
          </div>
        </header>

        {/* Main Content */}
        <main className="max-w-5xl mx-auto px-8 py-12">
          {/* Problem Header */}
          <div className="text-center mb-12">
            <div className={`inline-flex p-6 rounded-full mb-6 ${
              problem.category === 'literacy' 
                ? 'bg-gradient-to-br from-amber-500 to-orange-600' 
                : 'bg-gradient-to-br from-blue-500 to-indigo-600'
            } text-white shadow-2xl`}>
              {getIcon(problem.icon)}
            </div>
            <h1 className="text-4xl font-bold text-white mb-4">{problem.title}</h1>
            <p className="text-xl text-indigo-200">{problem.description}</p>
          </div>

          {/* Problem Details Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <Target className="h-6 w-6 text-amber-400" />
                  <CardTitle className="text-white">Impact Goal</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="text-indigo-200">
                <p>
                  Develop effective solutions to improve student outcomes in this critical area.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <Users className="h-6 w-6 text-blue-400" />
                  <CardTitle className="text-white">Target Audience</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="text-indigo-200">
                <p>
                  Students across various grade levels and educational contexts.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <Lightbulb className="h-6 w-6 text-green-400" />
                  <CardTitle className="text-white">Approach</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="text-indigo-200">
                <p>
                  Design thinking methodology to create innovative, student-centered solutions.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Action Section */}
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardHeader>
              <CardTitle className="text-white text-2xl">Next Steps</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-indigo-200 text-lg">
                Ready to start designing solutions for this problem? Use the design thinking framework to:
              </p>
              <ul className="list-disc list-inside space-y-2 text-indigo-200 ml-4">
                <li>Empathize with students and understand their needs</li>
                <li>Define the core problem more specifically</li>
                <li>Ideate potential solutions</li>
                <li>Prototype your best ideas</li>
                <li>Test and iterate based on feedback</li>
              </ul>
              <div className="flex gap-4 mt-6">
                <Button 
                  size="lg"
                  onClick={() => navigate(`/workflow/${id}`)}
                  className={`${
                    problem.category === 'literacy' 
                      ? 'bg-gradient-to-br from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700' 
                      : 'bg-gradient-to-br from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700'
                  } text-white shadow-lg`}
                >
                  Start Design Process
                </Button>
                <Button 
                  size="lg"
                  variant="outline"
                  className="border-white/30 text-[rgb(248,240,240)] hover:bg-white/10 bg-[rgb(230,37,37)]"
                  onClick={() => navigate('/')}
                >
                  Explore Other Problems
                </Button>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}