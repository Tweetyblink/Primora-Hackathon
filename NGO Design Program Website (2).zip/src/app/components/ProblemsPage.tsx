import { useParams, useNavigate } from 'react-router-dom';
import { literacyProblems, careerProblems, Problem } from '@/data/problems';
import { Button } from '@/app/components/ui/button';
import { Card, CardContent } from '@/app/components/ui/card';
import * as LucideIcons from 'lucide-react';
import { ArrowLeft } from 'lucide-react';
import nightSkyBg from 'figma:asset/1fed1153c2875de5502e9ab7a4d6b263492f0d7b.png';

export function ProblemsPage() {
  const { category } = useParams<{ category: 'literacy' | 'career' }>();
  const navigate = useNavigate();

  const problems = category === 'literacy' ? literacyProblems : careerProblems;
  const title = category === 'literacy' 
    ? 'Foundational Literacy & Numeracy' 
    : 'Career Readiness';

  const getIcon = (iconName: string) => {
    const Icon = (LucideIcons as any)[iconName];
    return Icon ? <Icon className="h-8 w-8" /> : null;
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${nightSkyBg})` }}
      />
      
      {/* Dark overlay for better text readability */}
      <div className="absolute inset-0 bg-black/20" />

      {/* Content */}
      <div className="relative z-10">
        {/* Header */}
        <header className="pt-8 px-8">
          <div className="max-w-7xl mx-auto">
            <Button
              variant="ghost"
              onClick={() => navigate('/')}
              className="text-white hover:bg-white/10 mb-4"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
            <h1 className="text-4xl font-bold text-white">{title}</h1>
            <p className="text-lg text-indigo-200 mt-2">
              Select a specific problem to address
            </p>
          </div>
        </header>

        {/* Problems Grid */}
        <main className="max-w-7xl mx-auto px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {problems.map((problem) => (
              <Card
                key={problem.id}
                className="group cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-2xl bg-white/10 backdrop-blur-sm border-white/20 overflow-hidden"
                onClick={() => navigate(`/problem/${problem.id}`)}
              >
                <CardContent className="p-6">
                  <div className="flex flex-col items-center text-center space-y-4">
                    <div className={`p-4 rounded-full ${
                      category === 'literacy' 
                        ? 'bg-gradient-to-br from-amber-500 to-orange-600' 
                        : 'bg-gradient-to-br from-blue-500 to-indigo-600'
                    } text-white shadow-lg group-hover:shadow-xl transition-shadow`}>
                      {getIcon(problem.icon)}
                    </div>
                    <h3 className="text-xl font-semibold text-white">
                      {problem.title}
                    </h3>
                    <p className="text-sm text-indigo-200 line-clamp-3">
                      {problem.description}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}