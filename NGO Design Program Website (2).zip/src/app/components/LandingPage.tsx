import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/app/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/app/components/ui/dropdown-menu';
import { Avatar, AvatarFallback } from '@/app/components/ui/avatar';
import { User, Plus, ChevronDown } from 'lucide-react';
import nightSkyBg from 'figma:asset/1fed1153c2875de5502e9ab7a4d6b263492f0d7b.png';

export function LandingPage() {
  const navigate = useNavigate();
  const [currentUser] = useState('John Doe');

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${nightSkyBg})` }}
      />
      
      {/* Dark overlay for better text readability */}
      <div className="absolute inset-0 bg-black/20" />

      {/* Content */}
      <div className="relative z-10">
        {/* Header with Profile */}
        <header className="pt-8 px-8">
          <div className="max-w-7xl mx-auto flex justify-between items-center">
            <h1 className="text-2xl font-bold text-white">Primora</h1>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-2 text-white hover:bg-white/10">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-indigo-600 text-white">
                      <User className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                  <span>{currentUser}</span>
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <User className="mr-2 h-4 w-4" />
                  <span>Switch Account</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Plus className="mr-2 h-4 w-4" />
                  <span>Add Account</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>View Workflows</DropdownMenuItem>
                <DropdownMenuItem>Create New Workflow</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex flex-col items-center justify-center min-h-[calc(100vh-120px)] px-4">
          <div className="text-center max-w-3xl mx-auto space-y-12">
            {/* Title */}
            <div className="space-y-4">
              <h2 className="text-5xl md:text-6xl font-bold text-white mb-4">
                Design Solutions for Impact
              </h2>
              <p className="text-xl text-indigo-200">
                Helping NGOs address critical educational challenges
              </p>
            </div>

            {/* Problem Selection */}
            <div className="space-y-6">
              <h3 className="text-2xl font-semibold text-white">
                What kind of problem are you facing?
              </h3>
              
              <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
                <Button
                  size="lg"
                  onClick={() => navigate('/problems/literacy')}
                  className="w-64 h-32 text-xl bg-gradient-to-br from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white shadow-2xl hover:shadow-orange-500/50 transition-all duration-300 transform hover:scale-105"
                >
                  <div className="flex flex-col items-center gap-2">
                    <span className="text-3xl">📚</span>
                    <span className="whitespace-normal text-wrap">Foundational Literacy & Numeracy</span>
                  </div>
                </Button>

                <Button
                  size="lg"
                  onClick={() => navigate('/problems/career')}
                  className="w-64 h-32 text-xl bg-gradient-to-br from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white shadow-2xl hover:shadow-blue-500/50 transition-all duration-300 transform hover:scale-105"
                >
                  <div className="flex flex-col items-center gap-2">
                    <span className="text-3xl">💼</span>
                    <span>Career Readiness</span>
                  </div>
                </Button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}