import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { LandingPage } from '@/app/components/LandingPage';
import { ProblemsPage } from '@/app/components/ProblemsPage';
import { ProblemDetail } from '@/app/components/ProblemDetail';
import { WorkflowPage } from '@/app/components/WorkflowPage';

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/problems/:category" element={<ProblemsPage />} />
        <Route path="/problem/:id" element={<ProblemDetail />} />
        <Route path="/workflow/:id" element={<WorkflowPage />} />
      </Routes>
    </Router>
  );
}